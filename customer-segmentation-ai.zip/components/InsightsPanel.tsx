
import React, { useState, useEffect } from 'react';
import { ProcessedCustomer, GeminiInsight } from '../types';
import { getClusterInsights } from '../services/geminiService';
import Card, { CardHeader, CardContent } from './Card';
import Loader from './Loader';
import { CLUSTER_COLORS } from '../constants';

interface InsightsPanelProps {
  clusteredData: ProcessedCustomer[] | null;
  isClustering: boolean;
}

const InsightsPanel: React.FC<InsightsPanelProps> = ({ clusteredData, isClustering }) => {
  const [insights, setInsights] = useState<GeminiInsight[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (clusteredData && !isClustering) {
      const fetchInsights = async () => {
        setIsLoading(true);
        setError(null);
        try {
          const result = await getClusterInsights(clusteredData);
          // Sort results by clusterId to maintain order
          result.sort((a, b) => a.clusterId - b.clusterId);
          setInsights(result);
        } catch (err) {
          setError('Failed to fetch insights. Please check your API key and network connection.');
          console.error(err);
        } finally {
          setIsLoading(false);
        }
      };
      fetchInsights();
    } else if (!clusteredData) {
      setInsights([]); // Clear insights when clustering is reset
    }
  }, [clusteredData, isClustering]);

  const renderContent = () => {
    if (isLoading || isClustering) {
      return <Loader text="Generating AI-powered insights..." />;
    }
    
    if (error) {
        return <div className="text-center text-red-500 p-4">{error}</div>;
    }

    if (insights.length === 0) {
      return (
        <div className="text-center text-gray-500 dark:text-gray-400 p-4">
          <p>AI-driven marketing strategies will appear here after segmentation.</p>
        </div>
      );
    }
    
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
        {insights.map((insight, index) => (
          <div key={insight.clusterId} className="bg-white dark:bg-gray-800 rounded-lg shadow-md border-l-4" style={{borderColor: CLUSTER_COLORS[index % CLUSTER_COLORS.length]}}>
            <div className="p-5">
              <h3 className="text-xl font-bold mb-2 text-gray-900 dark:text-white">{insight.clusterName}</h3>
              <p className="text-gray-600 dark:text-gray-300 mb-4 text-sm">{insight.description}</p>
              <div>
                <h4 className="font-semibold mb-2 text-gray-700 dark:text-gray-200">Marketing Strategies:</h4>
                <ul className="list-disc list-inside space-y-2 text-sm text-gray-600 dark:text-gray-400">
                  {insight.marketingStrategies.map((strategy, i) => (
                    <li key={i}>{strategy}</li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        ))}
      </div>
    );
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center space-x-3">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-indigo-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
            </svg>
            <h2 className="text-lg font-semibold text-gray-900 dark:text-white">Actionable Insights powered by Gemini</h2>
        </div>
        <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">Personalized marketing strategies for each customer segment.</p>
      </CardHeader>
      <CardContent>
        {renderContent()}
      </CardContent>
    </Card>
  );
};

export default InsightsPanel;
