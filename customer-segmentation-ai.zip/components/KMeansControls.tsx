
import React, { useState, useMemo, useEffect } from 'react';
import { ProcessedCustomer, Feature } from '../types';
import Card, { CardHeader, CardContent } from './Card';
import { calculateWcss } from '../services/kmeans';
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from 'recharts';
import Loader from './Loader';

interface KMeansControlsProps {
  numClusters: number;
  setNumClusters: (k: number) => void;
  selectedFeatures: Feature[];
  setSelectedFeatures: (features: Feature[]) => void;
  onRunClustering: () => void;
  isClustering: boolean;
  data: ProcessedCustomer[];
}

const allFeatures: Feature[] = ['Age', 'Annual Income (k$)', 'Spending Score (1-100)'];

const KMeansControls: React.FC<KMeansControlsProps> = ({
  numClusters,
  setNumClusters,
  selectedFeatures,
  setSelectedFeatures,
  onRunClustering,
  isClustering,
  data,
}) => {
  const [elbowData, setElbowData] = useState<{k: number, wcss: number}[]>([]);
  const [isCalculatingElbow, setIsCalculatingElbow] = useState(true);

  useEffect(() => {
    const calculateElbow = () => {
        setIsCalculatingElbow(true);
        if(selectedFeatures.length > 0) {
            const wcssValues = calculateWcss(data, selectedFeatures, 10);
            setElbowData(wcssValues);
        } else {
            setElbowData([]);
        }
        setIsCalculatingElbow(false);
    };
    // Debounce or run on feature change
    const timer = setTimeout(calculateElbow, 300);
    return () => clearTimeout(timer);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [data, selectedFeatures]);

  const handleFeatureChange = (feature: Feature) => {
    const newFeatures = selectedFeatures.includes(feature)
      ? selectedFeatures.filter(f => f !== feature)
      : [...selectedFeatures, feature];
    setSelectedFeatures(newFeatures);
  };

  return (
    <Card>
      <CardHeader>
        <h2 className="text-lg font-semibold text-gray-900 dark:text-white">Clustering Controls</h2>
        <p className="text-sm text-gray-500 dark:text-gray-400">Configure and run the K-Means algorithm.</p>
      </CardHeader>
      <CardContent className="space-y-6">
        <div>
          <label className="block text-md font-medium text-gray-700 dark:text-gray-300">Select Features</label>
          <div className="mt-2 grid grid-cols-1 sm:grid-cols-2 gap-2">
            {allFeatures.map(feature => (
              <label key={feature} className="flex items-center space-x-2 p-2 rounded-md hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors cursor-pointer">
                <input
                  type="checkbox"
                  className="h-4 w-4 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                  checked={selectedFeatures.includes(feature)}
                  onChange={() => handleFeatureChange(feature)}
                />
                <span className="text-sm">{feature}</span>
              </label>
            ))}
          </div>
        </div>
        
        <div>
          <label htmlFor="numClusters" className="block text-md font-medium text-gray-700 dark:text-gray-300">
            Number of Clusters (K): <span className="font-bold text-indigo-600 dark:text-indigo-400">{numClusters}</span>
          </label>
          <input
            id="numClusters"
            type="range"
            min="2"
            max="10"
            value={numClusters}
            onChange={e => setNumClusters(Number(e.target.value))}
            className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer dark:bg-gray-700 mt-2"
          />
        </div>

        <div>
            <h3 className="text-md font-medium text-gray-700 dark:text-gray-300 mb-2">Elbow Method for Optimal K</h3>
            <div className="h-64 w-full">
              {isCalculatingElbow ? <Loader text="Calculating WCSS..."/> : (
                 <ResponsiveContainer>
                    <LineChart data={elbowData} margin={{ top: 5, right: 30, left: -10, bottom: 5 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="rgba(128, 128, 128, 0.2)"/>
                      <XAxis dataKey="k" name="K" stroke="rgb(156 163 175)"/>
                      <YAxis stroke="rgb(156 163 175)"/>
                      <Tooltip />
                      <Legend />
                      <Line type="monotone" dataKey="wcss" name="WCSS" stroke="#8884d8" strokeWidth={2} dot={{r: 4}} activeDot={{r: 6}}/>
                    </LineChart>
                </ResponsiveContainer>
              )}
            </div>
        </div>

        <button
          onClick={onRunClustering}
          disabled={isClustering || selectedFeatures.length === 0}
          className="w-full flex justify-center items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:bg-indigo-300 disabled:cursor-not-allowed"
        >
          {isClustering ? (
            <>
            <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
            </svg>
            Clustering...
            </>
          ) : 'Generate Segments'}
        </button>
         {selectedFeatures.length === 0 && (
            <p className="text-center text-xs text-red-500">Please select at least one feature to run clustering.</p>
        )}
      </CardContent>
    </Card>
  );
};

export default KMeansControls;
