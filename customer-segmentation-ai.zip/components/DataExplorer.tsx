
import React from 'react';
import { ResponsiveContainer, ScatterChart, XAxis, YAxis, CartesianGrid, Tooltip, Scatter, Legend } from 'recharts';
import { ProcessedCustomer } from '../types';
import Card, { CardHeader, CardContent } from './Card';

interface DataExplorerProps {
  data: ProcessedCustomer[];
}

const DataExplorer: React.FC<DataExplorerProps> = ({ data }) => {
  return (
    <Card>
      <CardHeader>
        <h2 className="text-lg font-semibold text-gray-900 dark:text-white">Exploratory Data Analysis</h2>
        <p className="text-sm text-gray-500 dark:text-gray-400">Initial data distributions.</p>
      </CardHeader>
      <CardContent className="space-y-6">
        <div>
          <h3 className="text-md font-medium text-gray-700 dark:text-gray-300 mb-2">Income vs. Spending Score</h3>
          <div className="h-64 w-full">
            <ResponsiveContainer>
              <ScatterChart margin={{ top: 20, right: 20, bottom: 20, left: 20 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(128, 128, 128, 0.2)" />
                <XAxis type="number" dataKey="Annual Income (k$)" name="Annual Income (k$)" unit="k" stroke="rgb(156 163 175)"/>
                <YAxis type="number" dataKey="Spending Score (1-100)" name="Spending Score" unit="" stroke="rgb(156 163 175)"/>
                <Tooltip cursor={{ strokeDasharray: '3 3' }} />
                <Scatter name="Customers" data={data} fill="#8884d8" />
              </ScatterChart>
            </ResponsiveContainer>
          </div>
        </div>
        <div>
          <h3 className="text-md font-medium text-gray-700 dark:text-gray-300 mb-2">Age vs. Spending Score</h3>
          <div className="h-64 w-full">
            <ResponsiveContainer>
              <ScatterChart margin={{ top: 20, right: 20, bottom: 20, left: 20 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(128, 128, 128, 0.2)" />
                <XAxis type="number" dataKey="Age" name="Age" unit="" stroke="rgb(156 163 175)"/>
                <YAxis type="number" dataKey="Spending Score (1-100)" name="Spending Score" unit="" stroke="rgb(156 163 175)"/>
                <Tooltip cursor={{ strokeDasharray: '3 3' }} />
                <Scatter name="Customers" data={data} fill="#82ca9d" />
              </ScatterChart>
            </ResponsiveContainer>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default DataExplorer;
