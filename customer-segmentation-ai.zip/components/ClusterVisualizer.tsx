
import React from 'react';
import { ResponsiveContainer, ScatterChart, XAxis, YAxis, ZAxis, CartesianGrid, Tooltip, Scatter, Legend } from 'recharts';
import { ProcessedCustomer, Cluster, Feature } from '../types';
import { CLUSTER_COLORS } from '../constants';
import Card, { CardHeader, CardContent } from './Card';

interface ClusterVisualizerProps {
  data: ProcessedCustomer[] | null;
  clusters: Cluster[] | null;
  features: Feature[];
}

const CustomTooltip: React.FC<any> = ({ active, payload }) => {
  if (active && payload && payload.length) {
    const data = payload[0].payload;
    return (
      <div className="bg-white dark:bg-gray-800 p-3 border border-gray-200 dark:border-gray-700 rounded-md shadow-lg">
        <p className="font-bold text-gray-800 dark:text-gray-200">{`Customer ID: ${data.CustomerID}`}</p>
        <p className="text-sm text-gray-600 dark:text-gray-400">{`Age: ${data.Age}`}</p>
        <p className="text-sm text-gray-600 dark:text-gray-400">{`Income: $${data['Annual Income (k$)']}k`}</p>
        <p className="text-sm text-gray-600 dark:text-gray-400">{`Spending Score: ${data['Spending Score (1-100)']}`}</p>
        <p className="text-sm text-indigo-600 dark:text-indigo-400">{`Cluster: ${data.cluster + 1}`}</p>
      </div>
    );
  }
  return null;
};

const ClusterVisualizer: React.FC<ClusterVisualizerProps> = ({ data, clusters, features }) => {
  const getAxisKeys = (): { x: Feature; y: Feature; z?: Feature } => {
    const primaryFeatures: Feature[] = ['Annual Income (k$)', 'Spending Score (1-100)', 'Age'];
    const availableFeatures = primaryFeatures.filter(f => features.includes(f));
    
    return {
        x: availableFeatures[0] || 'Annual Income (k$)',
        y: availableFeatures[1] || 'Spending Score (1-100)',
        z: availableFeatures[2] || undefined,
    }
  };

  const {x, y} = getAxisKeys();

  const renderContent = () => {
    if (!data || !clusters) {
      return (
        <div className="flex items-center justify-center h-full text-gray-500">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 mr-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
          </svg>
          <p>Run clustering to see the results.</p>
        </div>
      );
    }
    
    const clusteredDataByGroup = clusters.map((_, i) => data.filter(d => d.cluster === i));

    return (
      <ResponsiveContainer width="100%" height="100%">
        <ScatterChart
          margin={{
            top: 20,
            right: 20,
            bottom: 20,
            left: 20,
          }}
        >
          <CartesianGrid strokeDasharray="3 3" stroke="rgba(128, 128, 128, 0.2)" />
          <XAxis type="number" dataKey={x} name={x} unit={x.includes("Income") ? "k" : ""} stroke="rgb(156 163 175)" />
          <YAxis type="number" dataKey={y} name={y} stroke="rgb(156 163 175)" />
          {features.length >= 3 && <ZAxis type="number" dataKey={'Age'} range={[60, 400]} name="Age" />}
          <Tooltip content={<CustomTooltip />} cursor={{ strokeDasharray: '3 3' }}/>
          <Legend />
          {clusteredDataByGroup.map((clusterData, i) => (
            <Scatter
              key={`cluster-${i}`}
              name={`Cluster ${i + 1}`}
              data={clusterData}
              fill={CLUSTER_COLORS[i % CLUSTER_COLORS.length]}
            />
          ))}
        </ScatterChart>
      </ResponsiveContainer>
    );
  };

  return (
    <Card>
      <CardHeader>
        <h2 className="text-lg font-semibold text-gray-900 dark:text-white">Customer Segments</h2>
        <p className="text-sm text-gray-500 dark:text-gray-400">
            Visualizing clusters based on selected features. {features.length >=3 && `(Size represents Age)`}
        </p>
      </CardHeader>
      <CardContent className="h-96">
        {renderContent()}
      </CardContent>
    </Card>
  );
};

export default ClusterVisualizer;
