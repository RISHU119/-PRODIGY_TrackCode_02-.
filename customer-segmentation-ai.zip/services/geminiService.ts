
import { GoogleGenAI, Type } from "@google/genai";
import { ProcessedCustomer, GeminiInsight } from '../types';

const getApiKey = (): string => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    throw new Error("API_KEY environment variable not set.");
  }
  return apiKey;
};

const ai = new GoogleGenAI({ apiKey: getApiKey() });

const summarizeCluster = (clusterData: ProcessedCustomer[]) => {
  if (clusterData.length === 0) return null;

  const summary = clusterData.reduce((acc, customer) => {
    acc.age += customer.Age;
    acc.income += customer['Annual Income (k$)'];
    acc.spendingScore += customer['Spending Score (1-100)'];
    acc.gender.male += customer.Gender === 0 ? 1 : 0;
    acc.gender.female += customer.Gender === 1 ? 1 : 0;
    return acc;
  }, {
    age: 0,
    income: 0,
    spendingScore: 0,
    gender: { male: 0, female: 0 },
  });

  const count = clusterData.length;
  return {
    count,
    avgAge: (summary.age / count).toFixed(1),
    avgIncome: (summary.income / count).toFixed(1),
    avgSpendingScore: (summary.spendingScore / count).toFixed(1),
    genderDistribution: `${((summary.gender.female / count) * 100).toFixed(0)}% Female, ${((summary.gender.male / count) * 100).toFixed(0)}% Male`,
  };
};

export const getClusterInsights = async (clusteredData: ProcessedCustomer[] | null): Promise<GeminiInsight[]> => {
  if (!clusteredData || clusteredData.length === 0) {
    return [];
  }

  const clusters: { [key: number]: ProcessedCustomer[] } = {};
  clusteredData.forEach(customer => {
    if (customer.cluster === undefined) return;
    if (!clusters[customer.cluster]) {
      clusters[customer.cluster] = [];
    }
    clusters[customer.cluster].push(customer);
  });

  const clusterSummaries = Object.entries(clusters).map(([clusterId, data]) => ({
    clusterId: parseInt(clusterId, 10),
    summary: summarizeCluster(data),
  }));

  const prompt = `
    You are an expert marketing analyst for a retail company.
    I have performed K-Means clustering on our customer data and have the following segments.
    For each customer segment, provide a creative, marketable name, a brief description of their characteristics, and 3-4 actionable, specific marketing strategies to target them.
    
    Here are the data summaries for each cluster:
    ${JSON.stringify(clusterSummaries, null, 2)}
    
    Your response MUST be a JSON array. Do not include any text before or after the JSON array.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              clusterId: { type: Type.NUMBER },
              clusterName: { type: Type.STRING, description: 'A creative, marketable name for the cluster (e.g., "Thrifty Shoppers", "Premium Loyalists").' },
              description: { type: Type.STRING, description: 'A brief summary of the key characteristics of this customer segment.' },
              marketingStrategies: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
                description: 'A list of 3-4 specific, actionable marketing strategies tailored to this segment.'
              },
            },
            required: ["clusterId", "clusterName", "description", "marketingStrategies"],
          },
        },
      },
    });

    const jsonText = response.text.trim();
    const insights = JSON.parse(jsonText);
    
    return insights as GeminiInsight[];

  } catch (error) {
    console.error("Error fetching insights from Gemini API:", error);
    // In case of error, generate a fallback message
    return clusterSummaries.map(s => ({
      clusterId: s.clusterId,
      clusterName: `Cluster ${s.clusterId + 1}`,
      description: `An error occurred while generating insights for this cluster. Please check the API key and console for details. Average Income: ${s.summary?.avgIncome}k, Average Spending Score: ${s.summary?.avgSpendingScore}.`,
      marketingStrategies: ["Retry the analysis.", "Verify API key configuration."],
    }));
  }
};
