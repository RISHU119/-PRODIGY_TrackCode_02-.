import { ProcessedCustomer, Feature, Centroid, Cluster } from '../types';

// Helper to convert a data point to a centroid object with only the specified features
const pointToCentroid = (point: ProcessedCustomer, features: Feature[]): Centroid => {
    const centroid: Centroid = {};
    for (const feature of features) {
        centroid[feature] = (point as any)[feature];
    }
    return centroid;
};

// --- Normalization ---
const normalizeData = (data: ProcessedCustomer[], features: Feature[]): { normalizedData: ProcessedCustomer[], minMax: { [key in Feature]?: { min: number, max: number } } } => {
  const minMax: { [key in Feature]?: { min: number, max: number } } = {};

  features.forEach(feature => {
    const values = data.map(d => d[feature]);
    minMax[feature] = { min: Math.min(...values), max: Math.max(...values) };
  });

  const normalizedData = data.map(d => {
    const newPoint = { ...d };
    features.forEach(feature => {
      const { min, max } = minMax[feature]!;
      if (max - min === 0) {
        newPoint[feature] = 0;
      } else {
        newPoint[feature] = (d[feature] - min) / (max - min);
      }
    });
    return newPoint;
  });

  return { normalizedData, minMax };
};

// --- Distance Calculation ---
const euclideanDistance = (point1: ProcessedCustomer | Centroid, point2: ProcessedCustomer | Centroid, features: Feature[]): number => {
  let sum = 0;
  for (const feature of features) {
    sum += Math.pow((point1 as any)[feature] - (point2 as any)[feature], 2);
  }
  return Math.sqrt(sum);
};

// --- Centroid Initialization (K-Means++) ---
const initializeCentroids = (data: ProcessedCustomer[], k: number, features: Feature[]): Centroid[] => {
  const centroids: Centroid[] = [];
  // 1. Choose one center uniformly at random from the data points.
  let firstCentroidPoint = data[Math.floor(Math.random() * data.length)];
  centroids.push(pointToCentroid(firstCentroidPoint, features));

  while (centroids.length < k) {
    const distances: number[] = [];
    data.forEach(point => {
      let minDistance = Infinity;
      centroids.forEach(centroid => {
        const dist = euclideanDistance(point, centroid, features);
        if (dist < minDistance) {
          minDistance = dist;
        }
      });
      distances.push(minDistance * minDistance); // D(x)^2
    });

    const totalDistance = distances.reduce((sum, d) => sum + d, 0);
    const randomValue = Math.random() * totalDistance;
    let sum = 0;

    for (let i = 0; i < distances.length; i++) {
      sum += distances[i];
      if (sum >= randomValue) {
        centroids.push(pointToCentroid(data[i], features));
        break;
      }
    }
  }
  return centroids;
};


// --- Main K-Means Algorithm ---
export const runKMeans = (
  data: ProcessedCustomer[], 
  k: number, 
  features: Feature[], 
  maxIterations = 100
): { clusters: Cluster[], assignments: number[] } => {
  if (features.length === 0 || data.length === 0) {
    return { clusters: [], assignments: [] };
  }

  const { normalizedData } = normalizeData(data, features);
  
  let centroids = initializeCentroids(normalizedData, k, features);
  let assignments: number[] = new Array(data.length).fill(0);
  let hasChanged = true;

  for (let i = 0; i < maxIterations && hasChanged; i++) {
    hasChanged = false;

    // Assignment step
    normalizedData.forEach((point, pointIndex) => {
      let minDistance = Infinity;
      let closestCentroidIndex = 0;

      centroids.forEach((centroid, centroidIndex) => {
        const distance = euclideanDistance(point, centroid, features);
        if (distance < minDistance) {
          minDistance = distance;
          closestCentroidIndex = centroidIndex;
        }
      });

      if (assignments[pointIndex] !== closestCentroidIndex) {
        hasChanged = true;
        assignments[pointIndex] = closestCentroidIndex;
      }
    });

    // Update step
    const newCentroids: Centroid[] = new Array(k).fill(0).map(() => ({}));
    const clusterCounts = new Array(k).fill(0);

    // Initialize new centroids with zero values for all features
    for (let j = 0; j < k; j++) {
        for (const feature of features) {
            newCentroids[j][feature] = 0;
        }
    }
    
    normalizedData.forEach((point, pointIndex) => {
      const clusterIndex = assignments[pointIndex];
      for (const feature of features) {
          newCentroids[clusterIndex][feature] += point[feature];
      }
      clusterCounts[clusterIndex]++;
    });

    newCentroids.forEach((centroid, index) => {
      if (clusterCounts[index] > 0) {
        for (const feature of features) {
            centroid[feature] /= clusterCounts[index];
        }
      } else {
        // Re-initialize empty clusters
        newCentroids[index] = pointToCentroid(normalizedData[Math.floor(Math.random() * normalizedData.length)], features);
      }
    });

    centroids = newCentroids;
  }

  const clusters: Cluster[] = centroids.map(centroid => ({ centroid, points: [] }));
  data.forEach((point, index) => {
    const clusterIndex = assignments[index];
    if(clusterIndex !== undefined && clusters[clusterIndex]) {
        clusters[clusterIndex].points.push(point);
    }
  });

  return { clusters, assignments };
};


// --- Elbow Method Calculation ---
export const calculateWcss = (data: ProcessedCustomer[], features: Feature[], maxK: number): { k: number, wcss: number }[] => {
  const wcssValues: { k: number, wcss: number }[] = [];
  if (features.length === 0 || data.length === 0) return wcssValues;

  const { normalizedData } = normalizeData(data, features);

  for (let k = 1; k <= maxK; k++) {
    const { assignments, clusters } = runKMeans(normalizedData, k, features, 50);
    let wcss = 0;
    
    normalizedData.forEach((point, pointIndex) => {
      const clusterIndex = assignments[pointIndex];
      if (clusterIndex !== undefined && clusters[clusterIndex]) {
        const centroid = clusters[clusterIndex].centroid;
        wcss += Math.pow(euclideanDistance(point, centroid, features), 2);
      }
    });
    wcssValues.push({ k, wcss });
  }

  return wcssValues;
};